/**
 * Created by latashawatson on 2/22/17.
 */
public abstract class DataStructureTemplate <E> {
    protected Object[] collection;

    public DataStructureTemplate() {
        collection = new Object[0];
    }

    public void add() {
    //don't add def...will be different for Map
    }

    public void clear() {
    //add def
    }

    public boolean isEmpty() {
        return false;   //add def
    }

    public boolean contains() {
        return false;
        //just declare...don't define here bc Map will need to have a different definition
    }

    public int size() {
        return 0;   //add def
    }

    public void remove() {
        //no definition...is different for arraylists
    }
}
