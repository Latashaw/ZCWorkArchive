/**
 * Created by latashawatson on 2/22/17.
 */
public class MyArrayList<E> extends DataStructureTemplate {


    public MyArrayList() {
        super.collection = new Object[0];
    }

    public MyArrayList(int size) {
        super.collection = new Object[size];
    }

    public void add(int index, E element) {
        int newIndex = super.collection.length + 1;
        Object[] newArray = new Object[newIndex];
        int j = 0;
        for (int i = 0; i < super.collection.length; i++) {
            if (index == i) {
                newArray[i] = element;
                j++;
            } else {
                newArray[j] = super.collection[i];
            }
            j++;
        }
        super.collection = newArray;
    }

    private void resize() {
        int newIndex = super.collection.length + 1;
        Object[] newArray = new Object[newIndex];
        for (int i = 0; i < super.collection.length; i++) {
            newArray[i] = super.collection[i];
        }
        super.collection = newArray;
    }

    public Object[] add(E element) {
        resize(); // increase size of super.collection by 1
        super.collection[super.collection.length] = element;
        return super.collection;
    }

    public E get(int index) {
        Object object = super.collection[index];
        return (E) object;
    }

    public void set(int index, E element) {
        super.collection[index] = element;
    }

    public void remove(int index) {
        int newIndex = super.collection.length - 1;
        Object[] newArray = new Object[newIndex];
        int j = 0;
        for (int i = 0; i < super.collection.length; i++) {
            if (index == i) {
                //don't add
                //offset indexes
                j++;
            } else {
                newArray[j] = super.collection[i];
            }
            j++;
        }
        super.collection = newArray;
    }

    public boolean contains(E element) {
        for (E collectionElement : (E[]) super.collection) {
            if (collectionElement.equals(element)) {
                return true;
            }
        }
        return false;
    }
}
