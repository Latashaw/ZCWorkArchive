/**
 * Created by latashawatson on 2/22/17.
 */
public class MySet <E> extends DataStructureTemplate{

    public void entrySet() {

    }

    public void get() {

    }

    public void hashcode() {

    }

    public void keySet() {

    }

    public void put() {

    }

    public void putAll() {

    }

    public void values() {

    }

}
