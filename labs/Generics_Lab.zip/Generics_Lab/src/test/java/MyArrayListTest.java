import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by latashawatson on 2/22/17.
 */
public class MyArrayListTest {
    MyArrayList mAL;

    @Before
    public void setup() {
        mAL = new MyArrayList(3);
        mAL.collection[0] = 1;
        mAL.collection[1] = "shnozzberries";
        mAL.collection[2] = 'F';
    }

    @Test
    public void clear1Test() {
        Object expected = null;
        mAL.clear();
        Object actual = mAL.collection[0];
        Assert.assertEquals("Values should be equal", expected, actual);
    }

    @Test
    public void clear2Test() {
        int expected = 1;
        mAL.clear();
        int actual = mAL.collection.length;
        Assert.assertEquals("Values should be equal", expected, actual);
    }

    @Test
    public void isEmptyTest() {
        boolean expected = false;
        boolean actual = mAL.isEmpty();
        Assert.assertEquals("Values should be equal", expected, actual);
    }

    @Test
    public void sizeTest() {
        int expected = 2;
        int actual = mAL.size();
        Assert.assertEquals("Values should be equal", expected, actual);
    }

    @Test
    public void removeTest() {
        int expected = 2;
        mAL.remove(0);
        int actual = mAL.collection.length;
        Assert.assertEquals("Values should be equal", expected, actual);
    }

    @Test
    public void addTest() {
        int expected = 3;
        mAL.add("raisins");
        int actual = mAL.collection.length;
        Assert.assertEquals("Values should be equal", expected, actual);
    }

    @Test
    public void addWithIndexTest() {
        int expected = 3;
        int actual = mAL.collection.length;
        Assert.assertEquals("Values should be equal", expected, actual);
    }

    @Test
    public void setTest() {
        String expected = "tasha";
        mAL.set(0,expected);
        String actual = (String) mAL.collection[0];
        Assert.assertEquals("Values should be equal", expected, actual);
    }

    @Test
    public void containsTest() {
        boolean expected = true;
        boolean actual = mAL.contains("shnozzberries");
        Assert.assertEquals("Values should be equal", expected, actual);
    }

    @Test
    public void getTest() {
        String expected = "shnozzberries";
        String actual = (String) mAL.get(1);
        Assert.assertEquals("Values should be equal", expected, actual);
    }

}