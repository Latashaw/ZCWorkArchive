import static org.junit.Assert.*;

/**
 * Created by latashawatson on 2/22/17.
 */
public class MyMapTest {

}